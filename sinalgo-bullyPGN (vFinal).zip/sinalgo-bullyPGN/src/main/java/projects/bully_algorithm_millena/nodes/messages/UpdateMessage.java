package projects.bully_algorithm_millena.nodes.messages;

import java.util.ArrayList;
import java.util.List;

import projects.bully_algorithm_millena.nodes.messages.BMessage.BMessageType;
import sinalgo.nodes.messages.Message;
import sinalgo.tools.Tuple;

public class UpdateMessage extends Message {
	public BMessageType msgType = BMessageType.UPdate;
	public int senderId;
	public List<Tuple<Integer, Boolean>> up = new ArrayList<>();

	public UpdateMessage(int sender, List<Tuple<Integer, Boolean>> up) {
		this.senderId = sender;
		this.up = up;
	}

	@Override
	public Message clone() {
		// TODO Auto-generated method stub
		return new UpdateMessage(senderId, up);
	}
}