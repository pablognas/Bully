package projects.bully_algorithm_millena.nodes.nodeImplementations;

import java.awt.Color;
import java.awt.Graphics;
import java.util.*;

import lombok.Getter;
import lombok.Setter;
import projects.bully_algorithm_millena.SystemConstants;
import projects.bully_algorithm_millena.nodes.messages.BMessage;
import projects.bully_algorithm_millena.nodes.messages.BMessage.BMessageType;
import projects.bully_algorithm_millena.nodes.timers.*;
import sinalgo.exception.WrongConfigurationException;
import sinalgo.gui.transformation.PositionTransformation;
import sinalgo.nodes.Node;
import sinalgo.nodes.messages.Inbox;
import sinalgo.nodes.messages.Message;
import sinalgo.runtime.nodeCollection.AbstractNodeCollection;
import sinalgo.tools.Tools;
import sinalgo.tools.logging.Logging;

@Getter
@Setter
public class BullyMobileNode extends Node {

	public enum NodeState {
		DOWN(-1), NORMAL(0), ELECTION(1), REORGANIZING(2);

		public int NodeStateValue;

		NodeState(int value) {
			this.NodeStateValue = value;
		}

		public void setNodeState(int state) {
			this.NodeStateValue = state;
		}

		public int getNodeState() {
			return this.NodeStateValue;
		}
	}

	public enum NodeDefnition {
		NORMAL, REORGANIZING, NEW_DEFINITION;
	}

	public long PID;
	public NodeState state;
	public long coord;
	public NodeDefnition definition;
	public List<Pair<Long, Boolean>> up = new ArrayList<>();
	public long halted;
	public boolean isCandidate = false;
	private int numAnswers = 0;

	Logging log = Logging.getLogger("bully_algorithm_log");

	public BullyMobileNode() {
		super();
		System.out.println("entrou no construtor vazio");
		this.PID = new java.util.Random().nextLong();
		this.state = NodeState.NORMAL;
		this.coord = 0;
		this.halted = 0;
		this.definition = NodeDefnition.NORMAL;
	}

	public BullyMobileNode(long pid) {
		super();
		System.out.println("entrou no construtor pid");
		this.PID = pid;
		this.state = NodeState.NORMAL;
		this.coord = 0;
		this.halted = 0;
		this.definition = NodeDefnition.NORMAL;

	}

	public BullyMobileNode(long id, long pid) {
		super();
		super.setID(id);
		this.PID = pid;
		this.state = NodeState.NORMAL;
		this.coord = 0;
		this.halted = 0;
		this.definition = NodeDefnition.NORMAL;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void handleMessages(Inbox inbox) {
		if (inbox.hasNext()) {
			Message msg = inbox.next();
			if (msg instanceof BMessage) {
				BMessage receivedMessage = (BMessage) msg;
				BMessage responseMessage = new BMessage(this, BMessageType.NONE);
				switch (receivedMessage.msgType) {
					case NONE: {

					}
					// Mensagem recebida pelos nós do coordenador para checar se estão disponíveis
					case AYNormal: {
						if (!this.isCoordenator()) {
							receivedMessage.getAckTimer().disable();
							responseMessage.messageUpdate(this, receivedMessage.getSender(),
									BMessageType.AYNormal_answer);
							// envia a resposta para o coordenador
							send(responseMessage, Tools.getNodeByID(this.getCoord()));
						}
						break;
					}
					// Coordenador recebe esta mensagem dos demais nós
					case AYUp: {
						if (receivedMessage.getData() == SystemConstants.ELECTION_MESSAGE) {
							receivedMessage.getAckTimer().disable();
							responseMessage.messageUpdate(this, receivedMessage.getSender(), BMessageType.AYUp_answer);
							responseMessage.setData(SystemConstants.ELECTION_MESSAGE);
							send(responseMessage, receivedMessage.getSender());
						} else if (this.isCoordenator()) {
							receivedMessage.getAckTimer().disable();
							responseMessage.messageUpdate(this, receivedMessage.getSender(), BMessageType.AYUp_answer);
							send(responseMessage, receivedMessage.getSender());
						}
						break;
					}
					case EnterElection: {
						// suspend application execution

						this.setState(NodeState.ELECTION);
						if (receivedMessage.getSender().getPID() > this.getPID()) {
							receivedMessage.getAckTimer().disable();
							this.setCandidate(false);
							this.setHalted(receivedMessage.getSender().getPID());
							responseMessage = new BMessage(this, BMessageType.EE_answer);
							send(responseMessage, receivedMessage.getSender());
						}
						break;
					}
					case SetCoord: {

						if (this.state == NodeState.ELECTION && this.halted == (long) receivedMessage.getData()) {
							receivedMessage.getAckTimer().disable();
							this.coord = (long) receivedMessage.getData();
							this.state = NodeState.REORGANIZING;
							responseMessage.messageUpdate(this, receivedMessage.getSender(), BMessageType.SC_answer);
							send(responseMessage, receivedMessage.getSender());
						}
						break;
					}
					case NewState: {
						if (this.coord == receivedMessage.getSender().getID() && this.state == NodeState.REORGANIZING) {
							receivedMessage.getAckTimer().disable();
							this.definition = (NodeDefnition) receivedMessage.getData();
							this.state = NodeState.NORMAL;
							responseMessage.messageUpdate(this, receivedMessage.getSender(), BMessageType.NS_answer);
							send(responseMessage, receivedMessage.getSender());

						}
						break;
					}
					case IAUp: {
						// ---------------------adicionar o código
						if (this.isCoordenator()) {
							int index = this.getUpIndexByPID(receivedMessage.getSender().getPID());

							if (index >= 0) {

								if (this.up.get(index).getStability()) {
									responseMessage.setData(true);

								} else {
									this.up.get(index).setStability(false);

								}
								responseMessage.messageUpdate(this, receivedMessage.getSender(),
										BMessageType.IAUp_answer);
								responseMessage.setData(false);
								send(responseMessage, receivedMessage.getSender());

							}
						}
						break;
					}
					case AYNormal_answer:
						if (this.isCoordenator()) {
							if ((this.getUpIndexByPID(receivedMessage.getSender().getPID()) == -1)
									|| (this.getUpIndexByPID(receivedMessage.getSender().getPID()) != -1
											&& receivedMessage.getSender().state != NodeState.NORMAL)) {
								this.Election();
							}
							receivedMessage.getAckTimer().disable();
						}
						break;
					case AYUp_answer:
						receivedMessage.getAckTimer().disable();
						if (receivedMessage.getData() == SystemConstants.ELECTION_MESSAGE) {
							if (receivedMessage.getSender().getPID() > this.getPID()) {
								this.setCandidate(false);
							}
						}
						break;
					case EE_answer:
						receivedMessage.getAckTimer().disable();
						this.up.add(new Pair<Long, Boolean>(receivedMessage.getSender().getPID(), true));

						break;
					case IAUp_answer:
						this.setState(NodeState.REORGANIZING);
						this.setCoord(receivedMessage.getSender().getID());
						break;
					case NS_answer:
						incrementNumAnswers();
						break;
					case SC_answer:
						incrementNumAnswers();
						break;
					case UPdate:
						if (!this.isCoordenator()) {
							this.setUp((List<Pair<Long, Boolean>>) receivedMessage.getData());
							responseMessage.getAckTimer().disable();
							responseMessage.messageUpdate(this, receivedMessage.getSender(),
									BMessageType.UPdate_answer);
							send(responseMessage, receivedMessage.getSender());
						}
						break;

					case UPdate_answer: {
						if (this.isCoordenator() && this.getUpIndexByPID(receivedMessage.getSender().getPID()) == -1) {
							Election();
						}
						break;
					}
					default:
						break;
				}
				// send(responseMessage, receivedMessage.getSender());

			}
		}

	}

	private void incrementNumAnswers() {
		this.numAnswers++;
	}

	public void Election() {
		// boolean highest = true;
		this.isCandidate = true;
		Tools.appendToOutput("[NODE " + getID() + "] started election" + "\n");
		try {
			Iterable<Node> nodes = Tools.getNodeList();
			while (nodes.iterator().hasNext()) {
				BullyMobileNode tmpNode = (BullyMobileNode) nodes.iterator().next();
				if (tmpNode.getPID() > this.getPID()) {
					BMessage msg = new BMessage(this, tmpNode);
					msg.setData(SystemConstants.ELECTION_MESSAGE);
					msg.setMsgType(BMessageType.AYUp);
					BullyMessageTimer AYUpTimer = new BullyMessageTimer(this, tmpNode.getPID(), true);
					AYUpTimer.startRelative(SystemConstants.TIMER_DURATION, this);
					msg.setAckTimer(AYUpTimer);
					send(msg, tmpNode);
				}

			}
			// wait(100);

			if (isCandidate) {
				this.state = NodeState.ELECTION;
				this.halted = getID();
				nodes = Tools.getNodeList();
				this.up.clear();
				while (nodes.iterator().hasNext()) {
					BullyMobileNode tmpNode = (BullyMobileNode) nodes.iterator().next();
					if (tmpNode.getPID() < this.getPID()) {
						BMessage msg = new BMessage(this, tmpNode);
						msg.setData(halted);
						msg.setMsgType(BMessageType.EnterElection);
						BullyMessageTimer eeTimer = new BullyMessageTimer(this, tmpNode.getPID(), true);
						eeTimer.startRelative(SystemConstants.TIMER_DURATION, this);
						msg.setAckTimer(eeTimer);
						send(msg, tmpNode);
					}

				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void preStep() {
		// Esse prestep executa antes de tratar mensagens recebidas

		switch (this.state) {
			case DOWN: {
				// inicia eleicao
			}
			case ELECTION: {
				// para a execução interna
			}
			case REORGANIZING: {

			}
			default: {
				// mantem funcionamento normal de enviar e responder mensagens periodicas
			}
		}

	}

	@Override
	public void init() {
		try {
			System.out.println("BullyMobileNode.init()");

			long newPID = new java.util.Random().nextLong();
			this.setPID(newPID);
			this.state = NodeState.NORMAL;
			this.coord = 0;
			this.halted = 0;
			this.definition = NodeDefnition.NORMAL;

		} catch (IllegalArgumentException e) {
			// Missing entry in the configuration file: Abort the simulation and
			// display a message to the user
			// throw new SinalgoFatalException("The initial state (specified in the config
			// file) must be DOWN, REORGANIZING, ELECTION or NORMAL.");
		}

	}

	@Override
	public void neighborhoodChange() {
		System.out.println("mudanças no neighborhood");
		Election();
	}

	@Override

	public void postStep() {

	}

	@Override
	public void checkRequirements() throws WrongConfigurationException {
		// if (this.getCoord() <= 0 || this.getState() == NodeState.DOWN) {
		// Election();
		// } else if (this.up.size() == 0 && this.getState() == NodeState.DOWN) {
		// throw new WrongConfigurationException(
		// "BullyMobileNode: not inicialized.");
		// }

	}

	public void draw(Graphics g, PositionTransformation pt, boolean highlight) {

		Color nodeColor;

		switch (this.state) {

			case DOWN: {
				nodeColor = Color.RED;
				break;
			}
			case REORGANIZING: {
				nodeColor = Color.YELLOW;
				break;
			}
			case ELECTION: {
				nodeColor = Color.BLACK;
				break;
			}

			default: {
				nodeColor = Color.GREEN;
			}

		}
		if (this.isCoordenator())
			nodeColor = Color.BLUE;

		// set the color of this node
		// this.setColor(new Color((float) 0.5 / (1 + this.state.getValue()), (float)
		// 0.5, (float) 1.0 / (1 + this.state.getValue())));
		this.setColor(nodeColor);

		// set the text of this node
		String text = "getID():" + getID() + " | " + this.state.toString().toLowerCase() + " ";

		// draw the node as a circle with the text inside
		super.drawNodeAsDiskWithText(g, pt, highlight, text, 14, Color.WHITE);
		// super.drawNodeAsSquareWithText(g, pt, highlight, text, 10, Color.YELLOW);
	}

	public boolean isCandidate() {
		return isCandidate;
	}

	public void setCandidate(boolean isCandidate) {
		this.isCandidate = isCandidate;
	}

	private boolean isCoordenator() {
		boolean isCoord = false;
		if (this.coord == getID()) {
			isCoord = true;
		}
		return isCoord;

	}

	public void checkCoordinator() {
		if (!this.isCoordenator()) {
			if (this.state == NodeState.NORMAL || this.state == NodeState.REORGANIZING) {
				BMessage msg = new BMessage(this, Tools.getNodeByID(this.getCoord()));
				msg.setMsgType(BMessageType.AYUp);
				BullyMessageTimer AYUpTimer = new BullyMessageTimer(this, this.getCoord(), true);
				AYUpTimer.startRelative(SystemConstants.TIMER_DURATION, this);
				msg.setAckTimer(AYUpTimer);
				send(msg, Tools.getNodeByID(this.getCoord()));
			}

		}
	}

	public void checkMembers() {
		if (isCoordenator() && this.state == NodeState.NORMAL) {
			BullyMobileNode tmpNode = null;
			BMessage msg = null;
			BullyMessageTimer AYNormalTimer = null;
			for (int i = 0; i < this.up.size(); i++) {
				tmpNode = (BullyMobileNode) Tools.getNodeByID(this.up.get(i).getId());
				msg = new BMessage(this, tmpNode);
				msg.setMsgType(BMessageType.AYNormal);
				AYNormalTimer = new BullyMessageTimer(this, tmpNode.getPID(), true);
				AYNormalTimer.startRelative(SystemConstants.TIMER_DURATION, this);
				msg.setAckTimer(AYNormalTimer);
				send(msg, tmpNode);
			}

		} else {
		}
	}

	@NodePopupMethod(menuText = "Start election")
	public void startElection() {
		Tools.appendToOutput("Manual election started with NODE " + this.getID() + "\n");
		Election();
	}

	public void EnterElection(BullyMobileNode candidate) {
		this.setState(NodeState.ELECTION);
		// parar execução local da aplicação
		if (candidate.getPID() > this.getPID()) {
			this.setCandidate(false);
			this.setHalted(candidate.getID());
			BMessage responseMessage = new BMessage(this, BMessageType.EE_answer);
			send(responseMessage, candidate);
		}
	}

	public void missingNode(long receiverPID) {
		if (this.isCoordenator() && this.getUpIndexByPID(receiverPID) != -1) { // tmpNode pertence a up
			this.up.get(this.getUpIndexByPID(receiverPID)).setStability(false);
			this.update();
		}
	}

	public long getID() {
		return super.getID();
	}

	public int getUpIndexByPID(long upPID) {
		int index = -1;
		for (int i = 0; i < up.size(); i++) {
			if (this.up.get(index) != null && this.up.get(index).id == upPID) {
				index = i;
				break;
			}
		}
		return index;
	}

	public void closeElection() {
		this.setCoord(this.getID());
		this.setState(NodeState.REORGANIZING);

		Tools.appendToOutput("New coordenation elected!\n");
		Tools.appendToOutput("[NODE " + this.getCoord() + " is the new coordenator with PID=" + this.getPID() + ".\n");

		this.numAnswers = 0;

		try {

			// -------------------- TRYING TO SET ALL NODES COORDINATORS
			AbstractNodeCollection nodes = Tools.getNodeList();
			while (nodes.iterator().hasNext()) {
				BullyMobileNode tmpNode = (BullyMobileNode) nodes.iterator().next();
				if (this.getUpIndexByPID(tmpNode.getPID()) != -1) { // tmpNode pertence a up
					BMessage msg = new BMessage(this, tmpNode);
					msg.setData(this.getID());
					msg.setMsgType(BMessageType.SetCoord);
					BullyMessageTimer scTimer = new BullyMessageTimer(this, tmpNode.getPID(), true);
					scTimer.startRelative(SystemConstants.TIMER_DURATION, this);
					msg.setAckTimer(scTimer);
					send(msg, tmpNode);
				}
			}

			wait(SystemConstants.TIMER_DURATION * Tools.getNodeList().size() * 100);
			if (numAnswers != up.size()) {
				Tools.appendToOutput("\nNew election started because missing acks\n");
				Election();
				return;
			}

			// --------------------------TRYING TO SET ALL NODES
			this.numAnswers = 0;
			nodes = Tools.getNodeList();
			while (nodes.iterator().hasNext()) {
				BullyMobileNode tmpNode = (BullyMobileNode) nodes.iterator().next();
				if (this.getUpIndexByPID(tmpNode.getPID()) != -1) { // tmpNode pertence a up
					BMessage msg = new BMessage(this, tmpNode);
					msg.setData(getDefinition());
					msg.setMsgType(BMessageType.NewState);
					BullyMessageTimer nsTimer = new BullyMessageTimer(this, tmpNode.getPID(), true);
					nsTimer.startRelative(SystemConstants.TIMER_DURATION, this);
					msg.setAckTimer(nsTimer);
					send(msg, tmpNode);
				}
			}

			wait(SystemConstants.TIMER_DURATION * Tools.getNodeList().size() * 100);
			if (numAnswers != up.size()) {
				Tools.appendToOutput("\nNew election started because missing acks\n");
				Election();
				return;
			}
			this.setState(NodeState.NORMAL);
			Tools.appendToOutput("[NODE " + getID() + "] new Coordinator" + "\n");

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void update() {
		if (state == NodeState.NORMAL && isCoordenator()) {
			AbstractNodeCollection nodes = Tools.getNodeList();

			BullyMobileNode tmpNode = (BullyMobileNode) nodes.iterator().next();
			if (this.getUpIndexByPID(tmpNode.getPID()) != -1) { // tmpNode pertence a up
				BMessage msg = new BMessage(this, tmpNode);
				msg.setData(this.up);
				msg.setMsgType(BMessageType.UPdate);
				BullyMessageTimer upTimer = new BullyMessageTimer(this, tmpNode.getPID(), true);
				upTimer.startRelative(SystemConstants.TIMER_DURATION, this);
				msg.setAckTimer(upTimer);
				send(msg, tmpNode);
			} else {
				Election();
			}
		}

	}

	private void recovery() {
		this.setState(NodeState.DOWN);
		BMessage msg = new BMessage(this, BMessageType.IAUp);
		broadcast(msg);

		if (this.state == NodeState.DOWN) {
			Tools.appendToOutput("\nNew election started because missing acks\n");
			Election();
		}
	}

	public void generateNewUp() {
		if (this.isCoordenator()) {
			AbstractNodeCollection nodes = Tools.getNodeList();
			BullyMobileNode tmpNode = null;
			while (nodes.iterator().hasNext()) {
				tmpNode = (BullyMobileNode) nodes.iterator().next();
				this.up.add(new Pair<Long, Boolean>(tmpNode.getPID(), true));
			}

		}

	}

	@NodePopupMethod(menuText = "Start")
	public void start() {
		// This sample project is designed for the round-based simulator.
		// I.e. a node is only allowed to send a message when it is its turn.
		// To comply with this rule, we're not allowed to call the
		// method 'SendMessage()' here, but need either to remember that the
		// user has clicked to send a message and then send it in the intervalStep()
		// manually. Here, we show a simpler and more elegant approach:
		// Set a timer (with time 1), which will fire the next time this node is
		// handled. The defaultProject already contains a MessageTimer which can
		// be used for exactly this purpose.

		Tools.appendToOutput("Start Routing from node " + this.getID() + "\n");
	}

}
