package projects.bully_algorithm_millena.nodes.timers;

import lombok.Getter;
import lombok.Setter;
import projects.bully_algorithm_millena.nodes.messages.BMessage.BMessageType;
import projects.bully_algorithm_millena.nodes.nodeImplementations.BullyMobileNode;
import sinalgo.nodes.timers.Timer;

@Getter
@Setter
public class BullyMessageTimer extends Timer {

    private BullyMobileNode sender;
    private long receiverPID;
    private boolean enabled = true;
    private BMessageType mType = BMessageType.NONE;

    public BullyMessageTimer(BullyMobileNode sender, long pID, boolean enabled) {
        super();
        this.sender = sender;
        this.receiverPID = pID;
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public void disable() {
        this.setEnabled(false);
    }

    @Override
    public void fire() {
        if (this.isEnabled()) {
            switch (this.mType) {
                case AYUp:
                    this.sender.Election();
                    break;
                case EnterElection:
                    this.sender.setCandidate(false);
                    break;
                case AYNormal:
                    this.sender.missingNode(this.receiverPID);
                    break;
                case UPdate:
                    this.sender.missingNode(this.receiverPID);
                    break;
                default:
                    break;
            }
        } else {
            switch (this.mType) {

                case EnterElection:
                    this.sender.closeElection();
                    break;

                default:
                    break;
            }
        }
    }
}