package projects.bully_algorithm_millena.nodes.messages;

import projects.bully_algorithm_millena.nodes.nodeImplementations.BullyMobileNode;
import projects.bully_algorithm_millena.nodes.timers.BullyMessageTimer;
import sinalgo.nodes.messages.Message;

public class BMessage extends Message {
	public enum BMessageType {
		NONE, AYUp, AYNormal, IAUp, AYUp_answer, AYNormal_answer, IAUp_answer, EnterElection, EE_answer, NewState,
		NS_answer, SetCoord, SC_answer, UPdate, UPdate_answer;
	}

	public BMessageType msgType;
	public BullyMobileNode sender;
	public BullyMobileNode target;
	public Object data;
	private BullyMessageTimer ackTimer;

	public BMessage(BullyMobileNode sender, Object data) {
		this.msgType = BMessageType.NONE;
		this.sender = sender;
		this.data = data;
	}

	public BMessage(BullyMobileNode sender, BullyMobileNode target, BMessageType type, Object data) {
		this.msgType = type;
		this.sender = sender;
		this.target = target;
		this.data = data;
	}

	public BMessage(BullyMobileNode sender, BullyMobileNode target, BMessageType type) {
		this.msgType = type;
		this.sender = sender;
		this.target = target;
	}

	public BMessage(BullyMobileNode sender, BMessageType type, Object data) {
		this.msgType = type;
		this.sender = sender;
		this.data = data;
	}

	public BMessage(BullyMobileNode sender, BMessageType type) {
		this.msgType = type;
		this.sender = sender;
		this.data = new String();
	}

	public void messageUpdate(BullyMobileNode sender, BullyMobileNode target, BMessageType type) {
		this.msgType = type;
		this.sender = sender;
		this.target = target;
	}

	public BMessageType getMsgType() {
		return msgType;
	}

	public void setMsgType(BMessageType msgType) {
		this.msgType = msgType;
	}

	public BullyMobileNode getSender() {
		return sender;
	}

	public void setSenderPId(BullyMobileNode sender) {
		this.sender = sender;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public BullyMobileNode getTarget() {
		return target;
	}

	public void setTarget(BullyMobileNode target) {
		this.target = target;
	}

	public void setSender(BullyMobileNode sender) {
		this.sender = sender;
	}

	public BullyMessageTimer getAckTimer() {
		return ackTimer;
	}

	public void setAckTimer(BullyMessageTimer ackTimer) {
		this.ackTimer = ackTimer;
	}

	@Override
	public Message clone() {
		return new BMessage(sender, target, msgType, data);
	}
}
