package projects.bully_algorithm_millena.nodes.nodeImplementations;

public class Pair<T1, T2> {
	long id;
	boolean stability;

	public Pair(long l, boolean st) {
		this.id = l;
		this.stability = st;
	}

	public Pair(long id) {
		this.id = id;
		this.stability = true;
	}

	public void setStability(boolean st) {
		this.setStability(st);
	}

	public boolean getStability() {
		return this.stability;
	}

	public long getId() {
		return this.id;
	}
}
