package projects.bully_algorithm_millena;

public final class SystemConstants {
	public static final int TIMER_DURATION = 10;
	public static final String ELECTION_MESSAGE = "ELECTION";
}
