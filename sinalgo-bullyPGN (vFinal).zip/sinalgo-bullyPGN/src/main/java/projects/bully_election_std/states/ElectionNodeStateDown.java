package projects.bully_election_std.states;

import projects.bully_election_std.nodes.messages.BullyMessage;
import projects.bully_election_std.nodes.nodeImplementations.ElectionNode;
import projects.bully_election_std.nodes.timers.ElectionTimeoutTimer;
import projects.bully_election_std.nodes.timers.WakeupTimeoutTimer;
import sinalgo.tools.Tools;
import java.util.Random;

public class ElectionNodeStateDown extends ElectionNodeState {
    public ElectionNodeStateDown(ElectionNode ctx) {
        super(ctx);
        ctx.up.clear();
        ctx.coordinatorId = -1;
        ctx.energy = 0;
    }

    @Override
    public void handleAYUp(BullyMessage msg) {

    }

    @Override
    public void handleAYOk(BullyMessage msg) {

    }

    @Override
    public void handleEnterElection(BullyMessage msg) {

    }

    @Override
    public void handleSetCoordinator(BullyMessage msg) {
    }

    @Override
    public void handleSetState(BullyMessage msg) {

    }

    @Override
    public void handleAck(BullyMessage msg) {
    }

    @Override
    public void handleTimeout() {
        ctx.c--;
        ctx.setState(States.ElectionCandidate);
        ctx.energy = 100;
    }

    @Override
    public void handleUpdate() {

        ctx.reliability--;
        
        if(ctx.reliability <= 0){
            ctx.reliability = 0;
        }

        if (ctx.getCurrentAntenna() != null) {
            Tools.appendToOutput("Node " + ctx.getID() + " found connection\n");
            if (ctx.activeTimeout == null) {
                ctx.activeTimeout = new ElectionTimeoutTimer(BullyMessage.MessageType.AYOk);
                ctx.activeTimeout.startRelative(1, ctx);
            }


            if (ctx.wakeupTimeout == null){
                Random random = new Random();

                Tools.appendToOutput("Criou wakeup timer " + ctx.getID() + " \n");
                ctx.wakeupTimeout = new WakeupTimeoutTimer();
                ctx.wakeupTimeout.startRelative(random.nextInt(10)+10, ctx);
            }else{
                  Tools.appendToOutput("Timer nao nulo " + ctx.getID() + " \n");
            }
            
        }



    }
}
