package projects.bully_election_std.nodes.timers;

import projects.bully_election_std.nodes.messages.BullyMessage;
import projects.bully_election_std.nodes.nodeImplementations.Antenna;
import projects.bully_election_std.nodes.nodeImplementations.ElectionNode;
import sinalgo.configuration.Configuration;
import sinalgo.exception.CorruptConfigurationEntryException;
import sinalgo.nodes.Position;
import sinalgo.nodes.timers.Timer;

public class WakeupTimeoutTimer extends Timer {
	public boolean shouldFire = true;

	@Override
	public void fire() {
		if(shouldFire) {
			ElectionNode mn = (ElectionNode) this.getTargetNode();
			mn.getState().handleTimeout();
			mn.wakeupTimeout = null;
			//System.out.print("fire!");
		}
	}

}
